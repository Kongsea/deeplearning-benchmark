# coding: utf-8
# pylint: disable=wildcard-import

"""Opencv plugin for mxnet"""
from .opencv import *

