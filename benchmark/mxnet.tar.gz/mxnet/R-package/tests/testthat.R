library(testthat)
library(mxnet)

test_check("mxnet")
